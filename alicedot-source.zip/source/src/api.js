import {createClient} from '@supabase/supabase-js';
import {fromRow} from './domain.js';
export function createApi(config){
 let url;try{url=new URL(config?.supabaseUrl);}catch{return null;}
 const key=config?.supabasePublishableKey||'';
 if(url.protocol!=='https:'||!url.hostname.endsWith('.supabase.co')||!key)return null;
 if(key.startsWith('sb_secret_'))throw Error('공개용 Publishable key만 사용할 수 있습니다.');
 if(key.split('.').length===3){try{const role=JSON.parse(atob(key.split('.')[1].replace(/-/g,'+').replace(/_/g,'/'))).role;if(role!=='anon')throw Error('BAD_KEY');}catch{throw Error('공개용 Publishable key 또는 anon 키를 사용해 주세요.');}}
 else if(!key.startsWith('sb_publishable_'))throw Error('Publishable key를 확인해 주세요.');
 const client=createClient(url.origin,key,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true,storage:sessionStorage}});
 const unwrap=r=>{if(r.error)throw r.error;return r.data;};
 return{client,
  async member(){return unwrap(await client.from('members').select('user_id,display_name').single());},
  async list(){return unwrap(await client.rpc('list_projects')).map(fromRow);},
  async save(p,version){return fromRow(unwrap(await client.rpc('save_project',{p_id:p.id,p_expected_version:version,p_payload:p})));},
  async archive(p){return fromRow(unwrap(await client.rpc('set_project_archived',{p_id:p.id,p_expected_version:p.version,p_archived:!p.archived})));},
  async history(id){return unwrap(await client.from('project_history').select('*').eq('project_id',id).order('id',{ascending:false}).limit(100));},
  async import(rows){return unwrap(await client.rpc('import_projects',{p_rows:rows}));}
 };
}
export function errorText(e){const s=String(e?.message||e||'');if(s.includes('VERSION_CONFLICT'))return '다른 구성원이 먼저 수정했습니다. 입력 내용은 화면에 남아 있습니다. 내용을 복사한 뒤 창을 닫고 최신 자료를 다시 열어 수정해 주세요.';if(s.includes('NOT_A_MEMBER')||e?.code==='42501')return '공유 공간 접근 권한을 확인해 주세요. 관리자에게 문의해 주세요.';if(/fetch|network|Failed to fetch|Load failed/i.test(s))return '연결이 끊어져 저장 여부를 확인하지 못했습니다. 입력 내용은 유지됩니다. 연결 후 새로고침으로 저장 여부를 확인해 주세요.';if(/INVALID|invalid|check constraint|out of range/i.test(s))return '입력 형식이나 금액·날짜 범위를 확인해 주세요.';return '요청을 처리하지 못했습니다. 잠시 후 다시 시도해 주세요.';}
