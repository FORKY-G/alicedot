export const statuses=['접수','작업중','작업완료','결제완료','캔슬'];
export const labels={name:'프로젝트명',year:'연도',month:'월',agency:'대행사',production:'프로덕션',director:'감독',pd:'담당 PD',initial:'최초견적',final:'최종견적',status:'작업상태',paidDate:'결제일',invoiceDate:'계산서 발행일',invoiceAmount:'계산서 발행액',company:'상호명',memo:'메모'};
export const moneyKeys=['initial','final','invoiceAmount'];
export const today=()=>{const a=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date());return ['year','month','day'].map(k=>a.find(x=>x.type===k).value).join('-');};
export function unpaid(p){return !['결제완료','캔슬'].includes(p.status);}
export function metrics(list){const live=list.filter(p=>!p.archived),active=live.filter(p=>p.status!=='캔슬'),sum=(rows,k)=>rows.reduce((n,p)=>n+(p[k]??0),0);return{initial:sum(live,'initial'),final:sum(active,'final'),paid:sum(active.filter(p=>p.status==='결제완료'),'final'),unpaid:sum(active.filter(unpaid),'final'),invoice:sum(live,'invoiceAmount')};}
export function fromRow(row){return {...row.data,id:row.id,version:row.version,created:row.created_on,archived:row.archived,updatedAt:row.updated_at,importKey:row.import_key};}
export function payload(p){return Object.fromEntries(Object.keys(labels).map(k=>[k,p[k]??(moneyKeys.includes(k)?null:'')]));}
export function parseMoney(value){if(value===null||value===undefined||String(value).trim()==='')return null;const str=String(value).replace(/[₩￦,\s]/g,'').replace(/원$/,'');if(!/^\d+$/.test(str))throw new Error('금액은 0 이상의 정수로 입력해 주세요.');const n=Number(str);if(!Number.isSafeInteger(n)||n>999999999999)throw new Error('금액이 허용 범위를 벗어났습니다.');return n;}
export function dateString(value,year){
 if(value===null||value===undefined||value==='')return '';
 let result;
 if(value instanceof Date){if(Number.isNaN(value.valueOf()))throw new Error('날짜를 확인해 주세요.');result=value.toISOString().slice(0,10);}
 else if(typeof value==='number'){result=new Date(Date.UTC(1899,11,30)+Math.round(value)*86400000).toISOString().slice(0,10);}
 else{const s=String(value).trim();const match=s.match(/^(?:(\d{4}|\d{2})[-./])?(\d{1,2})[-./](\d{1,2})\.?$/);if(!match)throw new Error('날짜를 YYYY-MM-DD 또는 MM-DD 형태로 입력해 주세요.');result=`${match[1]?(match[1].length===2?'20'+match[1]:match[1]):year}-${match[2].padStart(2,'0')}-${match[3].padStart(2,'0')}`;}
 const d=new Date(result+'T00:00:00Z');if(Number.isNaN(d.valueOf())||d.toISOString().slice(0,10)!==result||+result.slice(0,4)<2000||+result.slice(0,4)>2100)throw new Error('유효한 날짜가 아닙니다.');return result;
}
// AliceDot 월별 양식: B 월, D 날짜, E 프로젝트, J 상태, K/L 견적, O/P 계산서.
export function parseWorkbook(rows,year,sheet){
 if(!Number.isInteger(year)||year<2000||year>2100)throw new Error('가져올 연도를 확인해 주세요.');
 const records=[],errors=[],warnings=[];let month=0,header=false;
 for(let i=0;i<rows.length;i++){
  const r=rows[i]??[],name=String(r[4]??'').trim(),monthMatch=String(r[1]??'').trim().match(/^(1[0-2]|[1-9])월$/);
  if(name==='프로젝트명'){header=true;continue;}if(monthMatch)month=+monthMatch[1];
  if(!name||!header)continue;
  try{
   if(!month)throw new Error('B열에서 월을 찾을 수 없습니다.');
   const status=String(r[9]??'').trim()||'접수';if(!statuses.includes(status))throw new Error('알 수 없는 작업상태입니다.');
   const text=n=>String(r[n]??'').trim(),notes=[];
   const optionalDate=(cell,label)=>{try{return dateString(cell,year);}catch{const original=String(cell);warnings.push(`${i+1}행: ${label} '${original}' 확인이 필요합니다. 원문은 메모에 보존합니다.`);notes.push(`[가져오기 확인] ${label} 원문: ${original}`);return '';}};
   const paidDate=optionalDate(r[12],'결제일'),invoiceDate=optionalDate(r[14],'계산서 발행일');
   const data={year,month,name,agency:text(5),production:text(6),director:text(7),pd:text(8),status,initial:parseMoney(r[10]),final:parseMoney(r[11]),paidDate,invoiceDate,invoiceAmount:parseMoney(r[15]),company:text(16),memo:[text(17),...notes].filter(Boolean).join('\n')};
   const created_on=dateString(r[3],year);if(!created_on)warnings.push(`${i+1}행: 등록일이 비어 있어 가져오는 날짜로 기록합니다.`);
   if(name.length>120||Object.entries(data).some(([k,v])=>['agency','production','director','pd','company'].includes(k)&&v.length>160)||data.memo.length>3000)throw new Error('텍스트가 너무 깁니다.');
   records.push({row:i+1,data,created_on,source:`xlsx:${sheet}:${year}:${i+1}`});
  }catch(e){errors.push(`${i+1}행 ${name}: ${e.message}`);}
 }
 if(!header)errors.push('E열에서 프로젝트명 헤더를 찾을 수 없습니다. 기존 월별 견적서 양식을 선택해 주세요.');
 if(records.length>1000)errors.push('한 번에 1,000건까지 가져올 수 있습니다.');
 return{records,errors,warnings};
}
export function csv(list){const cols=[['year','연도'],['month','월'],['created','등록일'],...Object.entries(labels).filter(([k])=>!['year','month'].includes(k))];const q=x=>'"'+String(typeof x==='string'&&/^[\s]*[=+@-]/.test(x)?"'"+x:x??'').replace(/"/g,'""')+'"';return '\uFEFF'+[cols.map(([,title])=>q(title)).join(','),...list.map(p=>cols.map(([k])=>q(p[k])).join(','))].join('\r\n');}
