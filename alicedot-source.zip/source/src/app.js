import readXlsxFile,{readSheetNames} from 'read-excel-file';
import {statuses,labels,moneyKeys,today,unpaid,metrics,payload,parseMoney,parseWorkbook,csv} from './domain.js';
import {createApi,errorText} from './api.js';
const $=s=>document.querySelector(s),esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const backToTop=$('#back-to-top');
const updateBackToTop=()=>{backToTop.hidden=window.scrollY<320;};
window.addEventListener('scroll',updateBackToTop,{passive:true});
window.addEventListener('resize',updateBackToTop);
window.addEventListener('pageshow',updateBackToTop);
backToTop.addEventListener('click',()=>{
 $('#page-title').focus({preventScroll:true});
 window.scrollTo({top:0,behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'});
});
updateBackToTop();
const won=n=>Number(n||0).toLocaleString('ko-KR'),displayMoney=n=>n===null||n===''||n===undefined?'—':won(n);
let api,projects=[],member=null,user=null,editing=null,busy=false,loading=false,importRows=[],importEpoch=0,revision=0;
let state={year:Number(today().slice(0,4)),month:0,status:'전체',view:'all',query:''};
function message(id,text){$(id).textContent=text;$(id).hidden=!text;}
function notify(text){$('#toast').textContent=text;$('#toast').hidden=false;clearTimeout(notify.timer);notify.timer=setTimeout(()=>$('#toast').hidden=true,4500);}
function scoped(){return projects.filter(p=>p.year===state.year&&(!state.month||p.month===state.month)&&(state.view==='archive'?p.archived:!p.archived));}
const isUnpaid=unpaid;
function beforeStatus(){return scoped().filter(p=>(state.view!=='unpaid'||unpaid(p))&&(state.view!=='invoice'||p.invoiceDate||p.invoiceAmount>0)&&(!state.query||[p.name,p.agency,p.production,p.director,p.pd,p.company].join(' ').toLowerCase().includes(state.query)));}
function visible(){return beforeStatus().filter(p=>state.status==='전체'||p.status===state.status).sort((a,b)=>b.month-a.month||b.created.localeCompare(a.created)||a.id.localeCompare(b.id));}
function setBusy(value){busy=value;if(value)revision++;$('#workspace').classList.toggle('busy',value);for(const id of ['save-project','archive-project','import-confirm','add','refresh','import-open'])$('#'+id).disabled=value||(id==='import-confirm'&&!importRows.length);}
function showLogin(text=''){revision++;projects=[];member=null;user=null;$('#workspace').hidden=true;$('#login-screen').hidden=false;for(const d of document.querySelectorAll('dialog[open]'))d.close();message('#login-error',text);}
async function refresh({quiet=false}={}){
 if(loading||!member)return;loading=true;const requestRevision=revision;
 try{await api.member();const fresh=await api.list();if(requestRevision!==revision||!member)return;projects=fresh;message('#page-error','');$('#save-status').textContent=`최종 확인 ${new Intl.DateTimeFormat('ko-KR',{timeZone:'Asia/Seoul',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(new Date())} · 20초마다 자동 확인`;render();}
 catch(e){if(e.code==='PGRST116'||e.code==='42501'){showLogin('공유 공간 접근 권한을 확인해 주세요.');}else{message('#page-error','최신 자료를 가져오지 못했습니다. 마지막으로 확인한 내용입니다. 연결 후 새로고침해 주세요.');if(!quiet)notify(errorText(e));}}
 finally{loading=false;}
}
async function enter(session){
 if(!session){showLogin();return;}
 try{const m=await api.member(),fresh=await api.list();revision++;member=m;user=session.user;projects=fresh;$('#member-name').textContent=m.display_name;$('#login-screen').hidden=true;$('#workspace').hidden=false;$('#save-status').textContent='자료를 불러왔습니다 · 20초마다 자동 확인';render();}
 catch(e){showLogin(e.code==='PGRST116'?'구성원 등록이 필요합니다. 회사 관리자에게 문의해 주세요.':errorText(e));}
}

function render(){
 $('#page-title').textContent=({all:'프로젝트·매출 현황',unpaid:'미결제 관리',monthly:'월별 매출 현황',invoice:'계산서 관리',archive:'보관함'})[state.view];
 document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===state.view));
 $('#months').innerHTML=[0,...Array.from({length:12},(_,i)=>i+1)].map(m=>`<button type="button" data-month="${m}" class="${m===state.month?'active':''}">${m?m+'월':'전체'}</button>`).join('');
 const list=scoped(), m=metrics(projects.filter(p=>!p.archived&&p.year===state.year&&(!state.month||p.month===state.month))), blankFinal=list.filter(p=>p.status!=='캔슬'&&p.final===null).length;
 const cards=[['예상매출',m.initial,'최초견적 전체 합계'],['실매출',m.final,'최종견적 · 캔슬 제외'],['결제완료',m.paid,'결제완료 건의 최종견적'],['미지급금',m.unpaid,'미결제 건 · 캔슬 제외'],['계산서 발행액',m.invoice,'입력된 계산서 금액 합계']];
 $('#cards').innerHTML=cards.map(([label,value,note],i)=>`<div class="card ${i===1?'focus':''}"><div class="card-label">${label}</div><div class="metric">${won(value)}<small>원</small></div><div class="card-note">${note}</div></div>`).join('');
 const amounts=Array.from({length:12},(_,i)=>metrics(projects.filter(p=>!p.archived&&p.year===state.year&&p.month===i+1)).final),max=Math.max(...amounts,1);
 $('#chart').innerHTML=amounts.map((v,i)=>`<button type="button" class="barcol ${state.month===i+1?'current':''}" data-month="${i+1}" aria-label="${i+1}월 실매출 ${won(v)}원"><span class="barvalue">${v?won(Math.round(v/10000)):'—'}</span><i class="bar" style="height:${Math.max(3,v/max*93)}px"></i><span>${i+1}월</span></button>`).join('');
 $('#workload').innerHTML=['작업중','작업완료','결제완료','캔슬'].map((s,i)=>{const count=list.filter(p=>p.status===s).length;return `<div class="work-row"><span class="count-label">${s}</span><span class="track"><i style="width:${count/Math.max(1,list.length)*100}%;background:${['#d8b341','#80b58c','#d78b7c','#8caecc'][i]}"></i></span><strong>${count}건</strong></div>`;}).join('');
 const base=beforeStatus();$('#total-count').textContent=`${base.length}건`;
 $('#filters').innerHTML=['전체',...statuses].map(s=>`<button type="button" data-status="${s}" class="${s===state.status?'active':''}">${s}<b>${s==='전체'?base.length:base.filter(p=>p.status===s).length}</b></button>`).join('');
 const rows=visible();
 $('#rows').innerHTML=rows.length?rows.map(p=>`<tr class="row-${esc(p.status)}"><td><div class="project-name">${esc(p.name)}</div><div class="sub">${p.month}월 · 등록 ${esc(p.created.slice(5))} · ${esc(p.pd||'담당 미지정')}</div></td><td>${esc(p.agency||'—')}<div class="sub">${esc(p.production)}</div></td><td><select ${p.archived?'disabled':''} class="row-status status-${esc(p.status)}" data-id="${esc(p.id)}" aria-label="${esc(p.name)} 작업상태">${statuses.map(s=>`<option ${p.status===s?'selected':''}>${s}</option>`).join('')}</select></td><td class="num">${displayMoney(p.initial)}</td><td class="num"><strong>${displayMoney(p.final)}</strong></td><td class="num">${p.invoiceAmount?won(p.invoiceAmount):'—'}<div class="sub">${p.invoiceDate?esc(p.invoiceDate.slice(5)):p.invoiceAmount?'발행일 미입력':'미발행'}</div></td><td><button class="edit" data-edit="${esc(p.id)}" aria-label="${esc(p.name)} 상세 수정">상세</button></td></tr>`).join(''):'<tr><td colspan="7" class="empty">조건에 맞는 프로젝트가 없습니다. 다른 월이나 상태를 선택해 주세요.</td></tr>';
 $('#result-count').textContent=`${state.year}년 ${state.month?state.month+'월':'전체'} · ${rows.length}건 표시${blankFinal?' · 최종견적 미정 '+blankFinal+'건':''}`;

}

const firstYear=2025,lastYear=2100;
const years=Array.from({length:lastYear-firstYear+1},(_,i)=>firstYear+i).map(y=>`<option>${y}</option>`).join('');
$('#year').innerHTML=years;$('#year').value=state.year;$('#project-form').elements.namedItem('year').innerHTML=years;
$('#form-month').innerHTML=Array.from({length:12},(_,i)=>`<option value="${i+1}">${i+1}월</option>`).join('');$('#form-status').innerHTML=statuses.map(s=>`<option>${s}</option>`).join('');
function openEditor(id){
 const p=projects.find(x=>x.id===id);editing=p?structuredClone(p):{id:crypto.randomUUID(),version:0,created:today(),year:state.year,month:state.month||Number(today().slice(5,7)),status:'접수'};
 const f=$('#project-form');f.reset();for(const [k,v] of Object.entries(editing)){const field=f.elements.namedItem(k);if(field)field.value=v??'';}
 for(const el of f.querySelectorAll('input,select,textarea'))el.disabled=Boolean(p?.archived);
 $('#dialog-title').textContent=p?'프로젝트 상세':'새 프로젝트';$('#history-open').hidden=!p;$('#archive-project').hidden=!p;$('#archive-project').textContent=p?.archived?'복원하기':'보관하기';$('#save-project').hidden=Boolean(p?.archived);message('#form-error','');$('#editor').showModal();f.elements.namedItem('name').focus();
}
async function commit(p,version){const saved=await api.save(p,version);const idx=projects.findIndex(x=>x.id===saved.id);if(idx<0)projects.push(saved);else projects[idx]=saved;return saved;}
$('#add').addEventListener('click',()=>openEditor());
for(const id of ['close','cancel'])$('#'+id).addEventListener('click',()=>{if(!busy)$('#editor').close();});
document.addEventListener('click',e=>{const close=e.target.closest('[data-close]');if(close&&!busy)$('#'+close.dataset.close).close();const month=e.target.closest('[data-month]'),status=e.target.closest('[data-status]'),edit=e.target.closest('[data-edit]'),view=e.target.closest('[data-view]');if(month){state.month=Number(month.dataset.month);render();}if(status){state.status=status.dataset.status;render();}if(edit)openEditor(edit.dataset.edit);if(view){state.view=view.dataset.view;state.status='전체';render();if(state.view==='monthly')$('#monthly-panel').scrollIntoView({behavior:'smooth',block:'center'});}});
for(const d of document.querySelectorAll('dialog'))d.addEventListener('cancel',e=>{if(busy)e.preventDefault();});
$('#project-form').addEventListener('submit',async e=>{
 e.preventDefault();if(busy)return;const p=Object.fromEntries(new FormData(e.target));p.id=editing.id;p.year=Number(p.year);p.month=Number(p.month);p.name=p.name.trim();
 try{for(const k of moneyKeys)p[k]=parseMoney(p[k]);if(!p.name)throw Error('프로젝트명을 입력해 주세요.');}catch(e){message('#form-error',e.message);return;}
 setBusy(true);message('#form-error','');
 try{const saved=await commit(p,editing.version);$('#editor').close();state.year=saved.year;state.month=saved.month;state.status='전체';state.view='all';state.query='';$('#year').value=state.year;$('#search').value='';render();notify('공유 공간에 저장했습니다.');}
 catch(e){message('#form-error',errorText(e));await refresh({quiet:true});}finally{setBusy(false);}
});
$('#rows').addEventListener('change',async e=>{if(!e.target.matches('.row-status')||busy)return;const p=projects.find(x=>x.id===e.target.dataset.id);if(!p)return;setBusy(true);try{await commit({...payload(p),id:p.id,status:e.target.value},p.version);render();notify('작업상태와 합계가 반영되었습니다.');}catch(e){render();message('#page-error',errorText(e));await refresh({quiet:true});notify(errorText(e));}finally{setBusy(false);}});
$('#year').addEventListener('change',e=>{state.year=Number(e.target.value);render();});$('#search').addEventListener('input',e=>{state.query=e.target.value.trim().toLowerCase();render();});$('#refresh').addEventListener('click',()=>refresh());
$('#archive-project').addEventListener('click',async()=>{if(busy||!editing)return;const restore=editing.archived;if(!confirm(restore?'이 프로젝트를 복원하시겠습니까?':'프로젝트를 보관함으로 옮길까요? 매출 합계에서 제외되며 언제든 복원할 수 있습니다.'))return;setBusy(true);try{const saved=await api.archive(editing);projects=projects.map(p=>p.id===saved.id?saved:p);$('#editor').close();render();notify(restore?'프로젝트를 복원했습니다.':'보관함으로 옮겼습니다.');}catch(e){message('#form-error',errorText(e));await refresh({quiet:true});}finally{setBusy(false);}});
$('#history-open').addEventListener('click',async()=>{
 $('#history-content').textContent='수정 이력을 불러오는 중입니다.';$('#history-dialog').showModal();
 try{const rows=await api.history(editing.id);$('#history-content').innerHTML=rows.length?rows.map(h=>{const before=h.before_row?.data||{},after=h.after_row?.data||{};const changes=Object.keys(labels).filter(k=>String(before[k]??'')!==String(after[k]??'')).map(k=>`<li>${esc(labels[k])}: ${esc(before[k]??'—')} → ${esc(after[k]??'—')}</li>`).join('');return `<div class="history-item"><strong>${esc(h.actor_name)} · ${{create:'등록',update:'수정',archive:'보관',restore:'복원'}[h.action]}</strong><time>${esc(new Date(h.happened_at).toLocaleString('ko-KR',{timeZone:'Asia/Seoul'}))}</time><ul>${changes}</ul></div>`;}).join('')+'<p class="sub">최근 100개 이력을 표시합니다.</p>':'수정 이력이 없습니다.';}catch(e){$('#history-content').textContent=errorText(e);}
});
$('#export').addEventListener('click',()=>{const url=URL.createObjectURL(new Blob([csv(visible())],{type:'text/csv;charset=utf-8'})),a=document.createElement('a');a.href=url;a.download=`alicedot-${state.year}-${state.month||'all'}.csv`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);notify('현재 조회 목록을 내보냈습니다.');});
$('#import-open').addEventListener('click',()=>{$('#import-dialog').showModal();});
$('#import-file').addEventListener('change',async()=>{const file=$('#import-file').files[0];importRows=[];$('#import-confirm').disabled=true;message('#import-error','');$('#import-preview').textContent='';if(!file)return;const epoch=++importEpoch;try{if(file.size>15*1024*1024)throw Error('15MB 이하의 엑셀 파일을 선택해 주세요.');const names=await readSheetNames(file);if(epoch!==importEpoch)return;$('#import-sheet').innerHTML=names.map(n=>`<option>${esc(n)}</option>`).join('');const y=names.find(n=>/^20\d{2}$/.test(n));if(y){$('#import-sheet').value=y;$('#import-year').value=y;}await previewImport();}catch(e){message('#import-error',e.message||'엑셀 파일을 읽을 수 없습니다.');}});
for(const id of ['import-sheet','import-year'])$('#'+id).addEventListener('change',previewImport);
async function previewImport(){
 const file=$('#import-file').files[0],epoch=++importEpoch;importRows=[];$('#import-confirm').disabled=true;message('#import-error','');if(!file)return;
 try{const sheet=$('#import-sheet').value,rows=await readXlsxFile(file,{sheet});if(epoch!==importEpoch)return;const result=parseWorkbook(rows,Number($('#import-year').value),sheet),existing=new Set(projects.map(p=>p.importKey).filter(Boolean));
  importRows=result.errors.length?[]:result.records.map(r=>({id:crypto.randomUUID(),data:r.data,created_on:r.created_on,import_key:r.source}));
  const duplicates=importRows.filter(r=>existing.has(r.import_key)).length;
  $('#import-preview').innerHTML=`<strong>${result.records.length}건 확인 · 기존 가져오기 ${duplicates}건 건너뛰기</strong><p>시트명·연도·엑셀 행번호가 같은 기록은 다시 추가하지 않습니다. 표의 행 위치를 바꾸셨다면 중복 여부를 확인해 주세요.</p><table><thead><tr><th>행</th><th>월</th><th>프로젝트</th><th>상태</th><th>최종견적</th></tr></thead><tbody>${result.records.slice(0,30).map(r=>`<tr><td>${r.row}</td><td>${r.data.month}월</td><td>${esc(r.data.name)}</td><td>${esc(r.data.status)}</td><td>${displayMoney(r.data.final)}</td></tr>`).join('')}</tbody></table><p>앞의 30건을 표시합니다. 저장 시 확인된 전체 기록이 추가됩니다.</p>${result.warnings.length?'<p>'+result.warnings.slice(0,10).map(esc).join('<br>')+'</p>':''}`;
  message('#import-error',result.errors.slice(0,20).join('\n'));$('#import-confirm').disabled=!importRows.length;
 }catch(e){if(epoch===importEpoch){message('#import-error',e.message||'파일을 읽을 수 없습니다.');$('#import-preview').textContent='';}}
}
$('#import-confirm').addEventListener('click',async()=>{if(busy||!importRows.length)return;if(!confirm(`${importRows.length}건을 회사 공유 공간에 추가할까요? 기존 가져오기 기록은 건너뜁니다.`))return;setBusy(true);for(const id of ['import-file','import-sheet','import-year'])$('#'+id).disabled=true;try{const r=await api.import(importRows);$('#import-dialog').close();importRows=[];$('#import-file').value='';$('#import-preview').textContent='';await refresh();notify(`${r.imported}건 추가 · 중복 ${r.skipped}건 건너뛰었습니다.`);}catch(e){message('#import-error',errorText(e));}finally{for(const id of ['import-file','import-sheet','import-year'])$('#'+id).disabled=false;setBusy(false);}});
$('#login-form').addEventListener('submit',async e=>{e.preventDefault();if(!api)return;const f=new FormData(e.target),button=e.target.querySelector('button');button.disabled=true;message('#login-error','');try{const {data,error}=await api.client.auth.signInWithPassword({email:String(f.get('email')).trim(),password:String(f.get('password'))});if(error){message('#login-error','이메일과 비밀번호를 확인해 주세요. 계정이 없다면 관리자에게 요청해 주세요.');return;}e.target.reset();await enter(data.session);}catch{message('#login-error','로그인 서버에 연결할 수 없습니다. 잠시 후 다시 시도해 주세요.');}finally{button.disabled=false;}});
$('#logout').addEventListener('click',async()=>{if(busy)return;try{const r=await api.client.auth.signOut({scope:'local'});if(r.error){notify('로그아웃을 완료하지 못했습니다. 연결을 확인하고 다시 눌러 주세요.');return;}showLogin();}catch{notify('로그아웃을 완료하지 못했습니다. 연결을 확인해 주세요.');}});
$('#password-open').addEventListener('click',()=>{$('#password-form').reset();message('#password-error','');$('#password-dialog').showModal();});
$('#password-form').addEventListener('submit',async e=>{e.preventDefault();const f=new FormData(e.target),button=e.target.querySelector('[type=submit]');if(f.get('next')!==f.get('confirm')){message('#password-error','새 비밀번호가 일치하지 않습니다.');return;}button.disabled=true;try{const login=await api.client.auth.signInWithPassword({email:user.email,password:String(f.get('current'))});if(login.error){message('#password-error','현재 비밀번호를 확인해 주세요.');return;}const r=await api.client.auth.updateUser({password:String(f.get('next'))});if(r.error){message('#password-error','변경하지 못했습니다. 비밀번호 조건 또는 재인증 안내를 관리자와 확인해 주세요.');return;}$('#password-dialog').close();e.target.reset();notify('비밀번호를 변경했습니다.');}catch{message('#password-error','서버 연결을 확인해 주세요.');}finally{button.disabled=false;}});
async function init(){
 try{api=createApi(window.ALICEDOT_CONFIG);}catch(e){message('#setup-notice',e.message);}
 if(!api){$('#setup-notice').hidden=false;$('#demo-link').hidden=false;for(const e of $('#login-form').elements)e.disabled=true;return;}
 api.client.auth.onAuthStateChange((event)=>{if(event==='SIGNED_OUT')showLogin();});
 const {data,error}=await api.client.auth.getSession();if(error){showLogin('로그인 상태를 확인하지 못했습니다. 다시 로그인해 주세요.');return;}await enter(data.session);
 setInterval(()=>{if(member&&!document.hidden&&!busy)refresh({quiet:true});},20000);
 window.addEventListener('focus',()=>{if(member&&!busy)refresh({quiet:true});});
}
init().catch(()=>showLogin('공유 공간을 열지 못했습니다. 연결 설정과 인터넷 상태를 확인해 주세요.'));
