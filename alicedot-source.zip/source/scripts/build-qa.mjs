// 모의 API를 사용하는 화면 검증 전용 빌드입니다. 배포하지 마세요.
import {build} from 'esbuild';
import {cp,mkdir,readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';
await mkdir('dist',{recursive:true});await cp('public','dist',{recursive:true});
await build({entryPoints:['src/app.js'],outfile:'dist/app.js',bundle:true,format:'iife',platform:'browser',target:['es2022'],plugins:[{name:'qa-api',setup(b){b.onResolve({filter:/^\.\/api\.js$/},a=>a.importer.endsWith('/src/app.js')?{path:path.resolve('tests/qa-api.js')}:null);}}]});
const p='dist/index.html';await writeFile(p,(await readFile(p,'utf8')).replace('앨리스도트 공유 공간','화면 검증용 · 모의 데이터'));
