import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
const args=process.argv.slice(2), arg=(k,d)=>args.includes(k)?args[args.indexOf(k)+1]:d;
const port=Number(arg('--port',process.env.PORT||3000)), host=arg('--host','127.0.0.1');
const root=path.resolve('dist');
http.createServer(async(req,res)=>{
 try{let p=decodeURIComponent(new URL(req.url,'http://localhost').pathname);if(p==='/')p='/index.html';const f=path.resolve(root,'.'+p);if(!f.startsWith(root+path.sep)){res.writeHead(403);res.end();return;}
 const bytes=await fs.readFile(f);res.setHeader('Cache-Control','no-store');res.setHeader('Content-Type',({'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8'})[path.extname(f)]||'application/octet-stream');res.end(bytes);
 }catch{res.writeHead(404);res.end('Not found');}
}).listen(port,host,()=>console.log(`Local: http://${host}:${port}`));
