import test from 'node:test';
import assert from 'node:assert/strict';
import {metrics,parseWorkbook,parseMoney,dateString,csv} from '../src/domain.js';
test('취소·보관 제외와 지급/미지급 구분',()=>{
 const rows=[{initial:300,final:230,status:'작업중'},{initial:400,final:400,status:'결제완료',invoiceAmount:440},{initial:1000,final:1000,status:'캔슬'},{initial:9000,final:9000,status:'작업완료',archived:true},{initial:null,final:null,status:'접수'}];
 assert.deepEqual(metrics(rows),{initial:1700,final:630,paid:400,unpaid:230,invoice:440});
});
test('금액·날짜를 임의로 0으로 바꾸지 않음',()=>{assert.equal(parseMoney('₩1,000'),1000);assert.equal(parseMoney(''),null);assert.equal(parseMoney(0),0);assert.throws(()=>parseMoney('미정'));assert.throws(()=>parseMoney(-1));assert.throws(()=>dateString('02-30',2026));assert.equal(dateString('11-23',2026),'2026-11-23');});
test('월별 엑셀에서 집계 셀은 제외, 잘못된 프로젝트 행은 보고',()=>{const rows=[[],[null,null,null,null,'프로젝트명'],[null,'1월',1,'01-04','테스트','','','','','',100,90],[null,null,null,null,'오류','','','','','캔슬','미정',90],[null,'2월',1,null,'다음','','','','','작업완료',100,100]];const r=parseWorkbook(rows,2026,'2026');assert.equal(r.records.length,2);assert.equal(r.errors.length,1);assert.equal(r.records[0].data.status,'접수');assert.equal(r.records[1].data.month,2);assert.equal(r.warnings.length,1);});
test('내보내기 수식 실행 방지',()=>{assert.match(csv([{name:'=HYPERLINK("bad")'}]),/'=HYPERLINK/);});
test('두 자리 연도와 달력에 없는 결제일의 원문 보존',()=>{assert.equal(dateString('26.06.30',2026),'2026-06-30');const rows=[[null,null,null,null,'프로젝트명'],[null,'1월',1,'01-04','테스트','','','','','작업중',100,90,'26.06.31']];const r=parseWorkbook(rows,2026,'2026');assert.equal(r.errors.length,0);assert.equal(r.records[0].data.paidDate,'');assert.match(r.records[0].data.memo,/26.06.31/);assert.equal(r.warnings.length,1);});
